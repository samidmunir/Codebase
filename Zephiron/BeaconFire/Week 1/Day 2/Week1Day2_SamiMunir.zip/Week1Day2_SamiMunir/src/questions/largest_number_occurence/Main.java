package questions.largest_number_occurence;

public class Main {
    public static void main(String[] args) {
        Solution sol = new Solution();

        sol.computeLargestNumberAndOccurrence();
    }
}