public class Main {
    public static void main(String[] args) {
        System.out.println("Greetings, I am Sami M.");
        System.out.println("\nI am an avid developer with 10 years of programming experience across multiple tech stacks.");
        System.out.println("I love to learn new technologies and stay up to date with the industry's latest tools and concepts.");
        System.out.println("\tIn my free time I enjoy flight simulation from my home cockpit.");
        System.out.println("\nI am looking forward to my career with BeaconFire!");
    }
}